/*
 * Erick Rosas
 * DATE: 10/28/2022
 * (FRIDAY)
 */

import java.util.Scanner;
public class Exercise05_09 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		//Prompting the user
		//Assume that there are at least 2 students
		System.out.println("Enter the number of students: ");
		int numberOfStudents = input.nextInt();
		
		//Prompt to enter names and scores
		System.out.println("Enter a student name: ");
		String student1 = input.next();
		System.out.println("Enter a students score: ");
		double score1 = input.nextDouble();
		
		System.out.println("Enter a student name: ");
		String student2 = input.next();
		System.out.println("Enter a students score: ");
		double score2 = input.nextDouble();
		
		//Make sure Student1 has the higher score if not switching them
		if (score1 < score2) {
			
			//Swaping student1 and score1 with student2 and score2
			String tempStudent = student1;
			double tempScore = score1;
			student1 = student2;
			score1 = score2;
			student2 = tempStudent;
			score2 = tempScore;
			
		}
		//assert: score1 >= score2
		for(int i=0; i < numberOfStudents -2; i++) {
			System.out.println("Enter a student name: ");
			String student = input.next();
			System.out.println("Enter a students score: ");
			double score = input.nextDouble();
			
			//Making sure Score 1 is the highest score by swapping
			if (score > score1) {
				student2 = student1;
				score2 = score1;
				student1 = student;
				score1 = score;
			}
			else if (score > score2) {
				student2 = student;
				score2 = score;
				
			}
		}
		
		System.out.println("The Top Two Students: ");
		System.out.println(student1 + "'s score is " + score1);
		System.out.println(student2 + "'s score is " + score2);
		
		input.close();
	}

}
